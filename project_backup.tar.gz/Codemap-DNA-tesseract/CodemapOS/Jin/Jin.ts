export class Jin {
  static install(path: string): void {}
  static uninstall(path: string): void {}
  static reinstall(path: string): void {}
  static update(path: string): void {}
  static order(s: string): void {}
  static command(s1: string, s2: string): void {}
  static demand(s1: string, s2: string): void {}
}
