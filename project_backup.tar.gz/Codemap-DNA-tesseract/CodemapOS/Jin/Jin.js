export class Jin {
    static install(path) { }
    static uninstall(path) { }
    static reinstall(path) { }
    static update(path) { }
    static order(s) { }
    static command(s1, s2) { }
    static demand(s1, s2) { }
}
