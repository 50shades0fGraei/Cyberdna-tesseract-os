import { overrideSegment } from './VCS';
export function Warp(segment, override) {
    overrideSegment(segment, override);
}
