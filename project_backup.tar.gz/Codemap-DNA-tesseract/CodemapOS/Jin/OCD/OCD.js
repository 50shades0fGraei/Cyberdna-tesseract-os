import { stageSegment } from './VCS';
export function OCD(segment, state) {
    stageSegment(segment, state);
}
