import { executeSegment } from './VCS';
export function Drive(segment) {
    executeSegment(segment);
}
