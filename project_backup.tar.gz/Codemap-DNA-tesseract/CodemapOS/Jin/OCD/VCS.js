export function stageSegment(segment, state) { }
export function executeSegment(segment) { }
export function overrideSegment(segment, override) { }
