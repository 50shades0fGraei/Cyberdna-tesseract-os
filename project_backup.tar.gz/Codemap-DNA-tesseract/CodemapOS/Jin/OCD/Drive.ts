import { executeSegment } from './VCS';

export function Drive(segment: string): void {
  executeSegment(segment);
}
