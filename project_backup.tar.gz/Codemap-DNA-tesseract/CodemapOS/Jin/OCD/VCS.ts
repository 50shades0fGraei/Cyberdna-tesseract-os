export function stageSegment(segment: string, state: boolean): void {}

export function executeSegment(segment: string): void {}

export function overrideSegment(segment: string, override: string): void {}
