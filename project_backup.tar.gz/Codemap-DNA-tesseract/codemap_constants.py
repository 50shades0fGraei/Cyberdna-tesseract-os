# codemap_constants.py

TRAITS = [
    "Empathy", "Recursion", "Sovereignty", "Vigilance",
    "Entropy", "Integrity", "Expansion", "Reflection",
    "Adaptation", "Memory", "Intuition", "Precision", "Resonance"
]

PLANES = ["Emotion", "Logic", "Time", "Sovereignty"]

DUALITY = ["Forward", "Reverse"]