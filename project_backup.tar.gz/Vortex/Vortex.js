export class Vortex {
    addListener(callback) { }
}
